"""Stub for the Darwin-only _scproxy C module (iOS port).

The real module wraps SCDynamicStoreCopyProxies, which the iOS SDK marks
unavailable; this kit's devices take proxy settings from the standard
environment variables instead (http_proxy / https_proxy / no_proxy).
"""

def _get_proxy_settings():
    return {}


def _get_proxies():
    return {}


def get_proxies():
    return {}
