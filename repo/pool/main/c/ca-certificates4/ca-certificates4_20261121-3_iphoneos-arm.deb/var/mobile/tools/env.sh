# Source this (or add these directories to PATH) to use the armv7 kit
# tools with the managed CA bundle (ca-certificates4).
export PATH=/var/mobile/tools:/var/mobile/tools/bin:$PATH
export SSL_CERT_FILE=/var/mobile/tools/etc/ca-certificates/ca-bundle.crt
